
<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('content'); ?>
<div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Cadastrar Usuário</h4>
                    <p class="card-description"> Formulário</p>
                    <form class="form-inline" method="post" action="<?php echo e(action('UsuarioController@store')); ?>" enctype="multopar">
                        <?php echo csrf_field(); ?>
                      <label class="sr-only" for="inlineFormInputName2">Usuário</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" name="login" value="<?php echo e($usuario->login  ?? ''); ?>" id="" placeholder="Digite o usuário">

                      <label class="sr-only" for="inlineFormInputName2">Nome do Colaborador</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" name="nome" value="<?php echo e($usuario->nome  ?? ''); ?>" id="" placeholder="Digite o nome do Colaborador">

                      <label class="sr-only" for="inlineFormInputGroupUsername2">Senha</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" type="password" name="senha" value="<?php echo e($usuario->password ?? ''); ?>" id="" placeholder="Digite a senha">

                      <label class="sr-only" for="inlineFormInputGroupUsername2">E-mail</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" type="password" name="email" value="<?php echo e($usuario->email ?? ''); ?>" id="" placeholder="Digite o e-mail">

                      <label class="sr-only" for="inlineFormInputGroupUsername2">Funcão</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" type="text" name="funcao_id" value="<?php echo e($usuario->funcao_id ?? ''); ?>" id="" placeholder="Digite a função">

                      <label class="sr-only" for="inlineFormInputGroupUsername2">Master</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" type="text" name="master" value="<?php echo e($usuario->master ?? ''); ?>" id="" placeholder="Digite Master">

                      <label class="sr-only" for="inlineFormInputGroupUsername2">Permissões</label>
                       <input type="text" class="form-control mb-2 mr-sm-2" type="text" name="permissoes" value="<?php echo e($usuario->permissoes ?? ''); ?>" id="" placeholder="Digite a permissões">
                       
                       <label class="sr-only" for="inlineFormInputGroupUsername2">Admin</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" type="text" name="admin" value="<?php echo e($usuario->admin ?? ''); ?>" id="" placeholder="Digite Aqui">

                      <label class="sr-only" for="inlineFormInputGroupUsername2">Colaborador</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" type="text" name="colaborador" value="<?php echo e($usuario->colaborador ?? ''); ?>" id="" placeholder="Digite Aqui">
                     
                      <label class="sr-only" for="inlineFormInputGroupUsername2">gerente</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" type="text" name="gerente" value="<?php echo e($usuario->gerente ?? ''); ?>" id="" placeholder="Digite Aqui">

                      <label class="sr-only" for="inlineFormInputGroupUsername2">Comunicador Interno</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" type="text" name="comunicador_interno" value="<?php echo e($usuario->comunicador_interno  ?? ''); ?>" id="" placeholder="Digite o comunicador interno">
                      
                      <div class="form-group">
                          <label for="image">Selecione o arquivo</label>
                          <input type="file" name="image" value="<?php echo e($usuario->image ?? ''); ?>"></p>
                      </div>
                      

                     <button type="submit" class="btn btn-gradient-primary mb-2">Cadastrar</button>
                    </form>
                  </div>
                </div>
             </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('painel.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amazon\resources\views/painel/config/usuario-add.blade.php ENDPATH**/ ?>