
<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('content'); ?>
<style>
@import  url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');
*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}
body{
    display: flex;
    height: 100h;
    justify-content: center;
    align-items: center;
    padding: 10px;
    background: linear-gradient(135deg);
}
.container{
    
    width: 100%;
    background: #fff;
    padding: 25px 30px;
    border-radius: 5px;
    box-shadow: 0 5px 10px rgba(0,0,0,0.15);
}
.container .title{
    font-size: 25px;
    font-weight: 500;
    position: relative;

}
.container .title::before{
    content: '';
    position: absolute;
    left: 0;
    bottom: 0;
    height: 3px;
    width: 30px;
    background: linear-gradient(135deg, #71b7eb, 39b559b6);
}
.container form .user-details{
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  margin: 20px 0 12px 0;
}
form .user-details .input-box{
  margin-bottom: 13px;
  width: calc(100% / 2 - 20px);
}

.user-details .input-box input{
  height: 45px;
  width: 100%;
  outline: none;
  font-size: 16px;
  border-radius: 5px;
  padding-left: 15px;
  border: 1px solid #ccc;
  border-bottom-width: 2px;
  transition: all 0.3s ease;
}
form .category{
   display: flex;
   width: 80%;
   margin: 14px 0 ;
   justify-content: space-between;
 }
 form .category label{
   display: flex;
   align-items: center;
   cursor: pointer;
 }
 form button{
    height: 100px;
    margin: 100px 0;
 }
 form .button input{
   height: 100%;
   width: 100%;
   border-radius: 5px;
   border: none;
   color: #fff;
   font-size: 18px;
   font-weight: 500;
   letter-spacing: 1px;
   cursor: pointer;
   transition: all 0.3s ease;
   background: linear-gradient(135deg, #71b7e6, #9b59b6);
 }
 form input[type="radio"]{
   display: none;
 }





</style>
<!DOCTYPE html>
<!-- Designined by CodingLab - youtube.com/codinglabyt -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>  </title>
    <link rel="stylesheet" href="style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
<div class="container">
    <div class="title">Formulario de Vacinas</div>
    <div class="content">
      <form class="row" method="post" action="<?php echo e(action('VacinaController@store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="user-details">
          <div class="input-box">
            <span class="details">Nome do Colaborador</span>
            <input type="text" name="Nome" placeholder="Entre com nome do Colaborador" required>
          </div>
             <div class="input-box">
                <span class="details">Função</span>
                <input type="text"  name="Funcao" placeholder="Insira a Função a Função" required>
             </div>

             <div class="input-box">
                <span class="details">Idade</span>
                <input type="text"  name="Idade" placeholder="Insira a Função a Idade" required>
             </div>

             <div class="input-box">
                <span class="details">HepatiteB 1ºDose</span>
                <input type="date" name="HepB1°" placeholder="Insira a data" required>
             </div>

             <div class="input-box">
                <span class="details">HepatiteB 2ºDose</span>
                <input type="date" name="HepB2°" placeholder="Insira a data" required>
             </div>

             <div class="input-box">
                <span class="details">HepatiteB 3ºDose</span>
                <input type="date" name="HepB3°" placeholder="Insira a data" required>
             </div>

             <div class="input-box">
                <span class="details">Covid 1ºDose</span>
                <input type="date" name="Covid1°" placeholder="Insira a data" required>
             </div>

             <div class="input-box">
                <span class="details">Covid 2ºDose</span>
                <input type="date" name="Covid2°"placeholder="Insira a data" required>
             </div>

             <div class="input-box">
                <span class="details">Covid 3ºDose</span>
                <input type="date" name="Covid3°" placeholder="Insira a data" required>
             </div>

             <div class="input-box">
                <span class="details">Covid 4ºDose</span>
                <input type="date" name="Covid4°" placeholder="Insira a data" required>
             </div>

             <div class="input-box">
                <span class="details">DT 1ºDose</span>
                <input type="date" name="DuplaTetanica1°" placeholder="Insira a data" required>
             </div>

             <div class="input-box">
                <span class="details">DT 2ºDose</span>
                <input type="date" name="DuplaTetanica2°" placeholder="Insira a data" required>
             </div>

             <div class="input-box">
                <span class="details">DT 3ºDose</span>
                <input type="date" name="DuplaTetanica3°" placeholder="Insira a data" required>
             </div>

             <div class="input-box">
                <span class="details">DT Reforço</span>
                <input type="date" name="Dt_Reforco" placeholder="Insira a data" required>
             </div>

             <div class="input-box">
                <span class="details">Febre Amarela</span>
                <input type="date" name="FebreAmarela" placeholder="Insira a data" required>
             </div>

             <div class="input-box">
                <span class="details">Febre Amarela Reforço</span>
                <input type="date" name="Fb_Reforco" placeholder="Insira a data" required>
             </div> 

             <div class="input-box">
                <span class="details">Gripe Influenza</span>
                <input type="date" name="GripeInfluenza" placeholder="Insira a data" required>
             </div>

             <div class="input-box">
                <span class="details">Anti HBS Anterior</span>
                <input type="date" name="AntiHbsAnterior" placeholder="Insira a data" required>
             </div>

             <div class="input-box">
                <span class="details">Anti HBS Atual</span>
                <input type="date" name="AntiHbsAtual" placeholder="Insira a data" required>
             </div>

             <div class="input-box">
                <span class="details">Periodico Anterior</span>
                <input type="date" name="PeriodicoAnterior" placeholder="Insira a data" required>
             </div>
              
             <div class="input-box">
                <span class="details">Periodico Atual</span>
                <input type="date" name="PeriodicoAtual" placeholder="Insira a data" required>
             </div>

            

             <div class="input-box">
                <span class="details">Ativo</span>
                <input type="text" name="Ativo" placeholder="Insira Sim para Ativo Não para Inativo" required>
             </div>
             <div class="button">
                <input type="submit" value="Registrar">

             </div>
        </form>

    </div>

  </body>
  </html>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('painel.sesmt.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amazon\resources\views/painel/sesmt/vacinas.blade.php ENDPATH**/ ?>