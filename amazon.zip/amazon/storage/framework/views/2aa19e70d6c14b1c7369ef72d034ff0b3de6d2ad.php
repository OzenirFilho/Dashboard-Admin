
<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                  <style>
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-size: 10pt;
        font-family:  'arial', sans-serif:
      }

      html, body {
        width: 100%;
        height: 100%;
      }
      body {
        display: ;
        justify-content: center;
        align-items: center;
        background-color: #F5F5F5;
      }
      .tabela {
        display: block;
        background-color: #FFFFFF;
        box-shadow: 0px 0px 3px rgba(0, 0, 0, 0.3);
        max-height: 400px;
        overflow-x: hidden;
        overflow-x: scroll;
      }
      .tabela thead {
        background-color: #4CAF50;
      }
      .tabela thead tr th {
        text-align: left;
        color: #FFFFFF;
      }
      .tabela tbody tr:nth-child(even) {
        background-color: #EEEEEE;
      }
      .tabela th,
      .tabela td {
        padding: 15px;
        border: 1px solid #CCCCCC;
        max-width: 150px;
      }
      </style>
   </head>
<body>
    <div class="box">
    <h4 class="card-title">Listagem de Periodico</h4>
      <table class="tabela table-striped">
      <thead>
            <tr>
                <th>Id</th>
                <th>Nome</th>
                <th>Função</th>
                <th>Idade</th>
                <th>HepB 1ªDose</th>
                <th>HepB 2°Dose</th>
                <th>HepB 3°Dose</th>
                <th>Covid 1°Dose</th>
                <th>Covid 2°Dose</th>
                <th>Covid 3°Dose</th>
                <th>Covid 4°Dose</th>
                <th>DT 1°Dose</th>
                <th>DT 2°Dose</th>
                <th>DT 3°Dose</th>
                <th>DT Reforço</th>
                <th>Febre Amarela</th>
                <th>Fb Reforco</th>
                <th>GripeInfluenza</th>
                <th>Anti Hbs Anterior</th>
                <th>Anti Hbs Atual</th>
                <th>Periodico Anterior</th>
                <th>Periodcio Atual</th>
                <th>Ativo</th>
                <th>Ação</th>
             </tr>
           </thead>
         <tbody class="tb-content">
          <?php $__currentLoopData = $vacinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacina): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($vacina->id); ?></td>
            <td><?php echo e($vacina->Nome); ?></td>
            <td><?php echo e($vacina->Funcao); ?></td>
            <td><?php echo e($vacina->Idade); ?></td>
            <td><?php echo e($vacina->HepB1°); ?></td>
            <td><?php echo e($vacina->HepB2°); ?></td>
            <td><?php echo e($vacina->HepB3°); ?></td>
            <td><?php echo e($vacina->Covid1°); ?></td>
            <td><?php echo e($vacina->Covid2°); ?></td>
            <td><?php echo e($vacina->Covid3°); ?></td>
            <td><?php echo e($vacina->Covid4°); ?></td>
            <td><?php echo e($vacina->DuplaTetanica1°); ?></td>
            <td><?php echo e($vacina->DuplaTetanica2°); ?></td>
            <td><?php echo e($vacina->DuplaTetanica3°); ?></td>
            <td><?php echo e($vacina->Dt_Reforco); ?></td>
            <td><?php echo e($vacina->FebreAmarela); ?></td>
            <td><?php echo e($vacina->Fb_Reforco); ?></td>
            <td><?php echo e($vacina->GripeInfluenza); ?></td>
            <td><?php echo e($vacina->AntiHbsAnterior); ?></td>
            <td><?php echo e($vacina->AntiHbsAtual); ?></td>
            <td><?php echo e($vacina->PeriodicoAnterior); ?></td>
            <td><?php echo e($vacina->PeriodicoAtual); ?></td>
            <td><?php echo e($vacina->Ativo); ?></td>
            <td>
              <a href="">Editar</a> | <a href="">Excluir</a>
            </td>
     </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </tbody>
     </table>      
    </div>
  </div>
  </div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('painel.sesmt.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amazon\resources\views/painel/sesmt/resultados.blade.php ENDPATH**/ ?>