<!DOCTYPE html>
 <html land="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Comunicação Interna - HelpDesk</title>
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.1.2/css/all.min.css"/>
    </head>
    <body>
       <div class="wrapper">
        <section class="form signup">
            <header>Chat App Inmceb </header>
            <form action="#">
                <div class="error-txt">This is an error message!</div>
                <div class="name-details">
                    <div class="field">
                        <label>Primeiro Nome</label>
                        <input type="text" placeholder="Primeiro Nome">
                    </div>
                    <div class="field">
                        <label>E-mail</label>
                        <input type="text" placeholder="Insira seu email">
                    </div>
                    <div class="field">
                        <label>Senha</label>
                        <input type="text" placeholder="Insira sua senha">
                    </div>
                    <div class="field">
                        <label>Selecione sua Imagem</label>
                        <input type="file">
                    </div>
                    <div class="field">
                        <input type="submit" value="Continue para o Chat">
                    </div>

                </div>
            </form>
            <div class="link">Esqueceu sua Senha? <a href="#">Login now</a></div>
         </section>
       </div> 
    </body>
 </html>
<?php /**PATH C:\xampp\htdocs\amazon\resources\views/painel/chat/index.blade.php ENDPATH**/ ?>