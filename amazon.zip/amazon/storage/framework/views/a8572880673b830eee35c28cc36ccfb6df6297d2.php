
<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">

                  <div ng-controller="lanchoneteController">



                   </div>
                  </div>
                </div>
              </div>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('painel.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amazon\resources\views/painel/lanchonete/menu.blade.php ENDPATH**/ ?>