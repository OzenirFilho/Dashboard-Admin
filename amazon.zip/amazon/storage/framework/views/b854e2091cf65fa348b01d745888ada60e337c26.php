
<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
             <div class="card-body">
                <img src="<?php echo e(auth()->user()->avatar); ?>" style="width:150px; heigth:150px; float:left; border-radius:50%; margin-right:25px;">
                <div class="nav-profile-text d-flex flex-column">
                  <span class="font-weight-bold mb-2"><?php echo e(auth()->user()->nome); ?></span>
                     <form enctype="multipart/form-data" action="/profile" method="POST">
                        <label>Atualizar Foto do Perfil</label> 
                        <input type="file" name="avatar">
                        <input type="hidden" name="avatar" value="<?php echo e($usuario->avatar ?? ''); ?>">   
                        <input type="submit" class="pull-right btn btn-sm btn-primary">
                    </form>       

 
                
            
                 
                </div>
            </div>
        </div>
    </div>
</div>


                  
                 
               
              
<?php $__env->stopSection(); ?>
<?php echo $__env->make('painel.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amazon\resources\views/painel/config/profile.blade.php ENDPATH**/ ?>