<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'LoginController@form')->name('login');
Route::post('/login', 'LoginController@login');
Route::group(['middleware' => ['auth']], function(){
    Route::get('/logout', function(){
        Auth::logout();
        return redirect()->action('LoginController@form');
    })->name('logout');
    Route::get('/profile', 'UsuarioController@profile')->name('profile');
    Route::post('/profile', 'UsuarioController@update_avatar')->name('profile');
    Route::get('/usuario/add', 'UsuarioController@create')->name('usuario-add')->middleware('admin');
    Route::post('/usuario/add', 'UsuarioController@store');
    Route::get('/listagem', 'UsuarioController@storage')->name('listagem');
    Route::get('/listagem/edit/{id}', 'UsuarioController@edit');
    Route::get('/chat', 'ChatController@index')->name('chat');
    Route::get('/template', 'VacinaController@home')->name('template')->middleware('admin');
   
    Route::get('/vacinas', 'VacinaController@create')->name('vacinas');
    Route::post('/vacinas', 'VacinaController@store')->name('vacinas');
    
    Route::get('/resultados', 'VacinaController@show')->name('resultados');
    
    /*Rotas HelpDesk */
    Route::get('/chamado', 'ChamadoController@index')->name('chamado');
    Route::get('planilha', 'ChamadoController@store')->name('planilha');

    Route::get('/menu', 'LanchoneteController@index')->name('menu');
    Route::get('/layout', 'LavanderiaController@index')->name('layout');
    
    

    
});
    