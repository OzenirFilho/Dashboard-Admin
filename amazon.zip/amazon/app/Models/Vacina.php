<?php

/**
 * Created by Reliese Model.
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;

/**
 * Class Vacina
 * 
 * @property int $id
 * @property string|null $Nome
 * @property string|null $Funcao
 * @property string|null $Idade
 * @property string|null $HepB1°
 * @property string|null $HepB2°
 * @property string|null $HepB3°
 * @property string|null $Covid1°
 * @property string|null $Covid2°
 * @property string|null $Covid3°
 * @property string|null $Covid4°
 * @property string|null $DuplaTetanica1°
 * @property string|null $DuplaTetanica2°
 * @property string|null $DuplaTetanica3°
 * @property string|null $Dt_Reforco
 * @property string|null $FebreAmarela
 * @property string|null $Fb_Reforco
 * @property string|null $AntiHbsAnterior
 * @property string|null $AntiHbsAtual
 * @property string|null $GripeInfluenza
 * @property string|null $PeriodicoAnterior
 * @property string|null $PeriodicoAtual
 * @property string|null $Ativo
 * 
 * @property Collection|ContasUsuario[] $contas_usuarios
 *
 * @package App\Models
 */
class Vacina extends Model
{
	protected $table = 'vacinas';
	public $timestamps = false;

	protected $fillable = [
		'Nome',
		'Funcao',
		'Idade',
		'HepB1°',
		'HepB2°',
		'HepB3°',
		'Covid1°',
		'Covid2°',
		'Covid3°',
		'Covid4°',
		'DuplaTetanica1°',
		'DuplaTetanica2°',
		'DuplaTetanica3°',
		'Dt_Reforco',
		'FebreAmarela',
        'Fb_Reforco',
		'AntiHbsAnterior',
		'AntiHbsAtual',
		'GripeInfluenza',
		'PeriodicoAnterior',
		'PeriodicoAtual',
		'Ativo'
	];

	public function contas_usuarios()
	{
		return $this->hasMany(ContasUsuario::class, 'usuarios_flk');
	}
}
