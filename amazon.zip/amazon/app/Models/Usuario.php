<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Usuario extends Model
{
    protected $table = 'usuarios';
	public $timestamps = false;

	protected $hidden = [
		'password'
	];

	protected $fillable = [
		'login',
		'nome',
		'password',
		'email',
		'funcao_id',
		'master',
		'permissoes',
		'comunicador_interno',
		'admin',
		'colaborador',
		'gerente',
		'avatar'
		
	];
}
