<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Vacina;

class VacinaController extends Controller
{
   public function home(){
       return view('painel.sesmt.template');
   }

   public function index(){
       return view('painel.sesmt.vacinas');
}

   public function create(){
       $vacinas = Vacina::all();

       return view('painel.sesmt.vacinas', compact('vacinas'));
   }

   public function store(Request $request){
    //dd($request);

    $v = new Vacina;
    $v->Nome = $request->Nome;
    $v->Funcao = $request->Funcao;
    $v->Idade = $request->Idade;
    $v->HepB1° = $request->HepB1°;
    $v->HepB2° = $request->HepB2°;
    $v->HepB3° = $request->HepB3°;
    $v->Covid1° = $request->Covid1°;
    $v->Covid2° = $request->Covid2°;
    $v->Covid3° = $request->Covid3°;
    $v->Covid4° = $request->Covid4°;
    $v->DuplaTetanica1° = $request->DuplaTetanica1°;
    $v->DuplaTetanica2° = $request->DuplaTetanica2°;
    $v->DuplaTetanica3° = $request->DuplaTetanica3°;
    $v->Dt_Reforco = $request->Dt_Reforco;
    $v->FebreAmarela = $request->FebreAmarela;
    $v->Fb_Reforco = $request->Fb_Reforco;
    $v->GripeInfluenza = $request->GripeInfluenza;
    $v->PeriodicoAnterior = $request->PeriodicoAnterior;
    $v->PeriodicoAtual = $request->PeriodicoAtual;
    $v->AntiHbsAnterior = $request->AntiHbsAnterior;
    $v->AntiHbsAtual = $request->AntiHbsAtual;
    $v->Ativo = $request->Ativo;
    $v->save();
    
    return redirect()->action('VacinaController@create');
}

    public function show(){
        $vacinas = Vacina::all();

        return view('painel.sesmt.resultados', compact('vacinas'));
    }
 
}
