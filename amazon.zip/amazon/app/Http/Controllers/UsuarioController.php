<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Usuario;
use Image;

class UsuarioController extends Controller
{

    public function storage(){
       $usuarios = Usuario::all();
       return view('painel.config.listagem', compact('usuarios'));
    }

    public function create(){
        return view('painel.config.usuario-add');
    }

    public function profile(){
        return view('painel.config.profile');
    }

    public function update_avatar(Request $request){
           if($request->hasFile('avatar')){
            $avatar = $request->file('avatar');
            $filename = time() . '.' . $avatar->getClientOriginalExtenxion();
            Image::make($avatar)->resize(300, 300)->save( public_path('/uploads/avatar/' . $filename ) );

            $u = Auth::usuario();
            $u->avatar = $filename;
            $u->save();
           }
           return view('painel.config.usuario-add');
    }

    public function store(Request $request){
        //dd($request);

       $u = new Usuario;
       $u->login = $request->login;
       $u->nome = $request->nome;
       $u->password = bcrypt($request->senha);
       $u->email= $request->email;
       $u->funcao_id = $request->funcao_id;
       $u->master = $request->master;
       $u->admin= $request->admin;
       $u->gerente= $request->gerente;
       $u->colaborador= $request->colaborador;
       $u->permissoes = $request->permissoes;
       $u->comunicador_interno = $request->comunicador_interno;

       $u->image = $request->image;
       $u->save();
       
       return redirect()->action('UsuarioController@create')->with('msg', 'Colaborador criado com Sucesso!');

    } 

    public function edit($id){
        $usuario = Usuario::find($id);
        $usuarios = Usuario::all();

        if($usuario)
           return view('painel.config.usuario-add', compact('usuarios', 'usuario'));
        else
           return redirect()->action('UsuarioController@storage');
    }
}
