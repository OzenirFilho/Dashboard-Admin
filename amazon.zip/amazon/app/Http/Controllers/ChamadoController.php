<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ChamadoController extends Controller
{
   public function Index(){
        return view('painel.helpdesk.chamado'); 
   }
   public function store(){
      return view('painel.painel.planilha');
   }
}
