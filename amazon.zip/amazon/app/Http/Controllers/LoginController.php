<?php

namespace App\Http\Controllers;
use Auth;
use Illuminate\Http\Request;
use App\Models\Usuario;
use Hash;

class LoginController extends Controller
{
    public function form(){
        if(Auth::user())
             return view('painel.index');
        else     
             return view('login');
    }

    public function login(Request $request){
         
        $request->validate([
            'login' => 'required',
            'senha' => 'required'
        ]);

        $lembrar = empty($request->lembrar) ? false : true;
        $usuario = Usuario::where('login', $request->login)->first();

        if(!empty($usuario) && Hash::check($request->senha, $usuario->password)){
            Auth::loginUsingId($usuario->id, $lembrar);
        }
        return redirect()->action('LoginController@form');
    }
     
   public function logged($id){
       $array = array();
       $sql = "SELECT * usuarios WHERE id = :id";
       $sql->bindValue("id", $id);
       $sql->execute();

        if($sql->rowCount() > 0){
            $array = $sql->fetch();
        }
      return $array;
    }
}