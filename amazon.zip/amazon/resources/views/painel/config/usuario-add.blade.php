@extends('painel.template')
@section('title', '')
@section('content')
<div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Cadastrar Usuário</h4>
                    <p class="card-description"> Formulário</p>
                    <form class="form-inline" method="post" action="{{action('UsuarioController@store')}}" enctype="multopar">
                        @csrf
                      <label class="sr-only" for="inlineFormInputName2">Usuário</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" name="login" value="{{$usuario->login  ?? ''}}" id="" placeholder="Digite o usuário">

                      <label class="sr-only" for="inlineFormInputName2">Nome do Colaborador</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" name="nome" value="{{$usuario->nome  ?? ''}}" id="" placeholder="Digite o nome do Colaborador">

                      <label class="sr-only" for="inlineFormInputGroupUsername2">Senha</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" type="password" name="senha" value="{{$usuario->password ?? ''}}" id="" placeholder="Digite a senha">

                      <label class="sr-only" for="inlineFormInputGroupUsername2">E-mail</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" type="password" name="email" value="{{$usuario->email ?? ''}}" id="" placeholder="Digite o e-mail">

                      <label class="sr-only" for="inlineFormInputGroupUsername2">Funcão</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" type="text" name="funcao_id" value="{{$usuario->funcao_id ?? ''}}" id="" placeholder="Digite a função">

                      <label class="sr-only" for="inlineFormInputGroupUsername2">Master</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" type="text" name="master" value="{{$usuario->master ?? ''}}" id="" placeholder="Digite Master">

                      <label class="sr-only" for="inlineFormInputGroupUsername2">Permissões</label>
                       <input type="text" class="form-control mb-2 mr-sm-2" type="text" name="permissoes" value="{{$usuario->permissoes ?? ''}}" id="" placeholder="Digite a permissões">
                       
                       <label class="sr-only" for="inlineFormInputGroupUsername2">Admin</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" type="text" name="admin" value="{{$usuario->admin ?? ''}}" id="" placeholder="Digite Aqui">

                      <label class="sr-only" for="inlineFormInputGroupUsername2">Colaborador</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" type="text" name="colaborador" value="{{$usuario->colaborador ?? ''}}" id="" placeholder="Digite Aqui">
                     
                      <label class="sr-only" for="inlineFormInputGroupUsername2">gerente</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" type="text" name="gerente" value="{{$usuario->gerente ?? ''}}" id="" placeholder="Digite Aqui">

                      <label class="sr-only" for="inlineFormInputGroupUsername2">Comunicador Interno</label>
                      <input type="text" class="form-control mb-2 mr-sm-2" type="text" name="comunicador_interno" value="{{$usuario->comunicador_interno  ?? ''}}" id="" placeholder="Digite o comunicador interno">
                      
                      <div class="form-group">
                          <label for="image">Selecione o arquivo</label>
                          <input type="file" name="image" value="{{$usuario->image ?? ''}}"></p>
                      </div>
                      

                     <button type="submit" class="btn btn-gradient-primary mb-2">Cadastrar</button>
                    </form>
                  </div>
                </div>
             </div>
@endsection