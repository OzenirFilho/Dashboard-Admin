@extends('painel.template')
@section('title', '')
@section('content')
<div class="row">
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                  <h4 class="card-title">Usuários Cadastrados</h4>
                    
                    </p>
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th> # </th>
                          <th>Login</th>
                          <th> Senha</th>
                          <th> Funcão</th>
                          <th> Permissões</th>
                          <th> Master</th>
                          <th> comunicador Interno</th>
                          <th> Ação</th>
                         
                        </tr>
                      </thead>
                      <tbody>
                        @foreach($usuarios as $usuario)
                        <tr>
                            <td>{{$usuario->id}}</td>
                            <td>{{$usuario->login}}</td>
                            <td>{{$usuario->senha}}</td>
                            <td>{{$usuario->funcao_id}}</td>
                            <td>{{$usuario->permissoes}}</td>
                            <td>{{$usuario->master}}</td>
                            <td>{{$usuario->comunicador_interno}} </td>
                            <td>
                              <a href="/usuario/edit/{{$usuario->id}}">Alterar</a>  | <a href="">Remover</a> 
                             </td>
                           </tr>
                            @endforeach
                          
                      </tbody>
                    </table>
                  </div>
                </head>
                 <body>
        
               </div>
             </div>
                </div>
              </div>
        
@endsection