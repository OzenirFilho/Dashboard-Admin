@extends('painel.template')
@section('title', '')
@section('content')
<div class="row">
    <div class="col-12 grid-margin stretch-card">
        <div class="card">
             <div class="card-body">
                <img src="{{auth()->user()->avatar}}" style="width:150px; heigth:150px; float:left; border-radius:50%; margin-right:25px;">
                <div class="nav-profile-text d-flex flex-column">
                  <span class="font-weight-bold mb-2">{{auth()->user()->nome}}</span>
                     <form enctype="multipart/form-data" action="/profile" method="POST">
                        <label>Atualizar Foto do Perfil</label> 
                        <input type="file" name="avatar">
                        <input type="hidden" name="avatar" value="{{$usuario->avatar ?? ''}}">   
                        <input type="submit" class="pull-right btn btn-sm btn-primary">
                    </form>       

 
                
            
                 
                </div>
            </div>
        </div>
    </div>
</div>


                  
                 
               
              
@endsection