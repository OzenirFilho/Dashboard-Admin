@extends('painel.template')
@section('title', '')
@section('content')
<div class="row">
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                  

                  <div ng-controller="painelController" style='background-color: black; margin:0;padding:0;position: fixed;top: 0;left: 0;height: 100%; width: 100%;z-index: 10;'>
	<div style='height:110px;'>
		<div class="row" style='padding: 10px; vertical-align:middle;height:90px; background-color:#a8caf5;'>
			<div class="col-4" style='display:table-cell;vertical-align:middle;text-align:center;background-color:black;'>
				<span style='color:white;font-weight:bold;'> PAINEL DE CHAMADOS </span>
				<select class="form-control"  ng-model="painel.area" id="painelArea" ng-change="criarPainel(x)">
				<option ng-repeat="x in listaPainelArea" value="{{x.id}}">{{x.descricao}}</option></select>
			</div>
			<div class="col-2" style="background-color:#e8e3cd;">
				<table style="text-align:center;">
					<tr><td><b>Legenda de prioridade:</b></td></tr>  
					<tr><td>
						<span class="badge badge-danger">Alta</span>
						<span class="badge badge-warning">M&eacute;dia</span>
						<span class="badge badge-info">Baixa</span>
					</td></tr>
				</table>
			</div>
			<div class="col-4">
				<table class="table table-sm">
					<tr><td><a href="#" ng-click="cancelProgressBar()"><b>Pr&oacute;xima atualiza&ccedil;&atilde;o da lista de chamados:</b></a></td></tr>
					<tr><td ><div id="progress-bar" class="progress-bar progress-bar-striped progress-bar-animated bg-danger" role="progressbar" style="width: 0%" aria-valuenow="0%" aria-valuemin="0" aria-valuemax="100"></div></td></tr>
				</table>
			</div><!-- <span class="badge badge-primary">Primary</span>-->
			<div class="col-2"><button class="btn btn-success btn-block" ng-click="listarChamadoAreaEncerrados()">Chamados Encerrados</button></div>
		</div>
	</div>
	<hr class="style1">
	<div ng-cloak  >
		<div style="overflow-y: scroll;height: 450px;">
			<table class="table  table-striped table-dark">
				<tr>
					<th scope="col"></th>
					<th scope="col">Data</th>
					<th scope="col">Setor</th>
					<th scope="col">Solicitante</th>
					<th scope="col">T&iacute;tulo</th>
				</tr>
				<tr ng-repeat="x in listaChamadoArea">
					<td style="text-align: center;" 	ng-click="encerrarChamado(x)"><button ng-class="{'btn btn-danger btn-lg btn-block':x.urgencia_id==2, 'btn btn-warning btn-lg btn-block':x.urgencia_id==3, 'btn btn-info btn-lg btn-block':x.urgencia_id==4}">{{x.id}}</button></td>
					<td style="vertical-align: middle;"	ng-click="detalheChamado(x)"><b>{{x.data_chamado_format}}<br>{{x.hora_chamado}}</b></td>
					<td style="vertical-align: middle;"	ng-click="detalheChamado(x)"><b>{{x.area_origem_descricao}}</b></td>
					<td style="vertical-align: middle;"	ng-click="detalheChamado(x)"><b>{{x.primeiro_nome}}</b></td> <!--   | uppercase -->
					<td style="vertical-align: middle;"	ng-click="detalheChamado(x)"><b>{{x.titulo | uppercase}}{{x.area |uppercase}} >> {{x.problema | uppercase}}</b></td>
				</tr>
			</table>
		</div>			
	</div>		   
</div>				  						








                  
                   </div>
                  </div>
                </div>
              </div>
        
@endsection