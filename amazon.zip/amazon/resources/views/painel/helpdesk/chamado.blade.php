@extends('painel.template')
@section('title', '')
@section('content')

<div class="row">
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                  <div class="alert alert-secondary"><b>Help Desk >> Novo Chamado</b></div>

<div class="row">
	<div class="col-10">			
		<div class="form-group">
			<div style="padding: 5px;">
				<div class="row">
					<div class="col-5">	
						<label for="chamadoAreaOrigem"><span class="fonte_np14"><b>Onde voc&ecirc; est&aacute;?</b></span></label>
						<select class="form-control" ng-style="colorTextSelect1"  id="chamadoAreaOrigem" 
							ng-options = "lcao.id as lcao.descricao | uppercase for lcao in listaChamadoAreaOrigem " 
							ng-model="chamado.areaOrigem" 
							ng-disabled="novo"></select>
					</div>
					<div class="col-5">
						<label for="chamadoTipoDocumento"><span class="fonte_np14"><b>O que voc&ecirc; deseja?</b></span></label>
						<select class="form-control select2me " ng-style="colorTextSelect1" id="chamadoTipoDocumento" 
						ng-options = "lctd.id as lctd.descricao | uppercase for lctd in listaChamadoTipoDocumento" 
						ng-model="chamado.tipoDocumento" ng-disabled="novo"></select>
					</div>
					<div class="col-2">
						<label for="chamadoUrgencia"><span class="fonte_np14"><b>Urg&ecirc;ncia:</b></span></label>
						<select class="form-control" ng-style="colorTextSelect1"  id="chamadoUrgencia" 
							ng-options = "lcu.id as lcu.descricao  |uppercase for lcu in listaChamadoUrgencia" 
							ng-model="chamado.urgencia"  
							ng-disabled="novo"></select>
					</div>
				</div>
			</div>   
            <div  style="padding: 5px;">
				<div class='row'>
					<div class='col-5'><label for="chamadoAreaDestino"><span class="fonte_np14"><b>Quem vai resolver meu problema?</b></span></label></div>
					<div class='col-5'>
						<select class="form-control" ng-style="colorTextSelect1" id="chamadoAreaDestino" 
							ng-options = "lcad.id as lcad.descricao  |uppercase for lcad in listaChamadoAreaDestino |orderBy:'-descricao' track by lcad.id" 
							ng-model="chamado.areaDestino" 
							ng-change="listarSubArea()"  
							ng-disabled="novo"></select>
					</div>
					<div class='col-2'><button ng-class="{'btn btn-outline-dark btn-sm':novoProblema==false, 'btn btn-dark btn-sm':novoProblema==true}" ng-click="problemaNovo()">Não encontrei!</button></div>
				</div>
				<div style="padding: 25px;" ng-if="chamado.areaDestino" ng-show="!novoProblema">
					<div style="text-align: right;background-color: bisque;" class="row">
						<div class="col-2"><label for="chamadoSubArea"><span class="fonte_np14">&Aacute;rea: </span></label></div>
						<div class="col-10">
							<select class="form-control" ng-style="colorTextSelect2" id="chamadoSubArea" 
								ng-options = "lcsa.id as lcsa.descricao  |uppercase for lcsa in listaChamadoSubArea track by lcsa.id" 
								ng-model="chamado.subArea" 
								ng-change="listarSubAreaItem()" 
								ng-disabled="novo">
							</select>
						</div>
					</div>
					<div style="text-align: right; background-color: bisque;" class="row">
						<div class="col-2"><label for="chamadoSubAreaItem"><span class="fonte_np14">Problema:</span></label></div>
						<div class="col-10">	
							<select class="form-control" ng-style="colorTextSelect2" id="chamadoSubAreaItem" 
								ng-options = "lcsai.id as lcsai.descricao  |uppercase for lcsai in listaChamadoSubAreaItem track by lcsai.id" 
								ng-model="chamado.subAreaItem"  
								ng-disabled="novo">
							</select>
						</div>
					</div>
				</div>
			</div>
            <div  style="padding: 5px;" ng-if="novoProblema">
				<div class="row">
					<div class="col-12">
						<label for="chamadoTitulo"><span class="fonte_np14"><b>Titulo do Chamado:</b></span></label><span class="fonte_nr10"> ({}})</span>
						<input type="text" id="chamadoTitulo" ng-style="colorTextSelect1" class="form-control input-lg" 
								ng-model="chamado.titulo" maxlength="80"  ng-disabled="novo">
					</div>
				</div>
			</div>
			<div  style="padding: 5px;">
				<label for="chamadoDescricao"><span class="fonte_np14"><b>Descri&ccedil;&atilde;o/Observa&ccedil;&atilde;o:</b></span><span class="fonte_nr10"> ({{}})</span></label>
<!-- 					<input type="checkbox"  class="form-check-input" 
						ng-model="chamado.copiarTitulo" ng-disabled="novo" id="checkCopiarTitulo" 
						ng-change='copiarTitulo()'> 
				<label class="form-check-label" for="checkCopiarTitulo">Copiar Titulo?</label>-->
				<textarea id="chamadoDescricao" ng-style="colorTextSelect1" class="form-control" maxlength="1000" ng-model="chamado.descricao" ng-disabled="novo"></textarea>
				<span style="padding-left: 15px; color:red; font-size: 12px; font-weight: bold;">Atenção:</span> 
				<span style="padding-left: 15px; color:black; font-size: 11px; font-weight: bold;">Não usar aspas e nem caracteres especiais.</span>
			</div>
		</div>
	</div>
<!-- 	<div class="col-2" style="border: 1px solid navy; border-radius: 5px; text-align: center;" ng-show='!novo'>
		Atalhos...<hr class="style1">
		<a class="btn btn-outline-info btn-sm btn-block" ng-click="chamadoAtalho('Quadro de Dietas',2,31,35,3)" href="">Quadro de Dietas</a> 
		<a class="btn btn-outline-info btn-sm btn-block" ng-click="chamadoAtalho('Requisicao de Veículos',2,1,73,66)" href="">Requisicao Veiculos</a>
	</div>
 --></div











                    </div>
                  </div>
                </div>
              </div>
        
@endsection