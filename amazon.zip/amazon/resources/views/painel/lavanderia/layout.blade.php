@extends('painel.template')
@section('title', '')
@section('content')
<div class="row">
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                  






                  
                   </div>
                  </div>
                </div>
              </div>
        
@endsection