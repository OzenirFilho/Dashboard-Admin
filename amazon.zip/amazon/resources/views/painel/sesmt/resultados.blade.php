@extends('painel.sesmt.template')
@section('title', '')
@section('content')
<div class="row">
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                  <style>
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-size: 10pt;
        font-family:  'arial', sans-serif:
      }

      html, body {
        width: 100%;
        height: 100%;
      }
      body {
        display: ;
        justify-content: center;
        align-items: center;
        background-color: #F5F5F5;
      }
      .tabela {
        display: block;
        background-color: #FFFFFF;
        box-shadow: 0px 0px 3px rgba(0, 0, 0, 0.3);
        max-height: 400px;
        overflow-x: hidden;
        overflow-x: scroll;
      }
      .tabela thead {
        background-color: #4CAF50;
      }
      .tabela thead tr th {
        text-align: left;
        color: #FFFFFF;
      }
      .tabela tbody tr:nth-child(even) {
        background-color: #EEEEEE;
      }
      .tabela th,
      .tabela td {
        padding: 15px;
        border: 1px solid #CCCCCC;
        max-width: 150px;
      }
      </style>
   </head>
<body>
    <div class="box">
    <h4 class="card-title">Listagem de Periodico</h4>
      <table class="tabela table-striped">
      <thead>
            <tr>
                <th>Id</th>
                <th>Nome</th>
                <th>Função</th>
                <th>Idade</th>
                <th>HepB 1ªDose</th>
                <th>HepB 2°Dose</th>
                <th>HepB 3°Dose</th>
                <th>Covid 1°Dose</th>
                <th>Covid 2°Dose</th>
                <th>Covid 3°Dose</th>
                <th>Covid 4°Dose</th>
                <th>DT 1°Dose</th>
                <th>DT 2°Dose</th>
                <th>DT 3°Dose</th>
                <th>DT Reforço</th>
                <th>Febre Amarela</th>
                <th>Fb Reforco</th>
                <th>GripeInfluenza</th>
                <th>Anti Hbs Anterior</th>
                <th>Anti Hbs Atual</th>
                <th>Periodico Anterior</th>
                <th>Periodcio Atual</th>
                <th>Ativo</th>
                <th>Ação</th>
             </tr>
           </thead>
         <tbody class="tb-content">
          @foreach($vacinas as $vacina)
          <tr>
            <td>{{$vacina->id}}</td>
            <td>{{$vacina->Nome}}</td>
            <td>{{$vacina->Funcao}}</td>
            <td>{{$vacina->Idade}}</td>
            <td>{{$vacina->HepB1°}}</td>
            <td>{{$vacina->HepB2°}}</td>
            <td>{{$vacina->HepB3°}}</td>
            <td>{{$vacina->Covid1°}}</td>
            <td>{{$vacina->Covid2°}}</td>
            <td>{{$vacina->Covid3°}}</td>
            <td>{{$vacina->Covid4°}}</td>
            <td>{{$vacina->DuplaTetanica1°}}</td>
            <td>{{$vacina->DuplaTetanica2°}}</td>
            <td>{{$vacina->DuplaTetanica3°}}</td>
            <td>{{$vacina->Dt_Reforco}}</td>
            <td>{{$vacina->FebreAmarela}}</td>
            <td>{{$vacina->Fb_Reforco}}</td>
            <td>{{$vacina->GripeInfluenza}}</td>
            <td>{{$vacina->AntiHbsAnterior}}</td>
            <td>{{$vacina->AntiHbsAtual}}</td>
            <td>{{$vacina->PeriodicoAnterior}}</td>
            <td>{{$vacina->PeriodicoAtual}}</td>
            <td>{{$vacina->Ativo}}</td>
            <td>
              <a href="">Editar</a> | <a href="">Excluir</a>
            </td>
     </tr>
          @endforeach
       </tbody>
     </table>      
    </div>
  </div>
  </div>
 </div>
@endsection