@extends('painel.sesmt.template')
@section('title', '')
@section('content')

          estive aqui                
              
@endsection