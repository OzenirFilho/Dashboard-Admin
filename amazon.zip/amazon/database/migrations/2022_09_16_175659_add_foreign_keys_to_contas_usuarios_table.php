<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddForeignKeysToContasUsuariosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('contas_usuarios', function (Blueprint $table) {
            $table->foreign(['usuarios_flk'], 'fk_contas_has_usuarios_usuarios1')->references(['id'])->on('vacinas')->onUpdate('NO ACTION')->onDelete('NO ACTION');
            $table->foreign(['contas_flk'], 'fk_contas_has_usuarios_contas')->references(['id'])->on('medical')->onUpdate('NO ACTION')->onDelete('NO ACTION');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('contas_usuarios', function (Blueprint $table) {
            $table->dropForeign('fk_contas_has_usuarios_usuarios1');
            $table->dropForeign('fk_contas_has_usuarios_contas');
        });
    }
}
