<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateContasUsuariosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('contas_usuarios', function (Blueprint $table) {
            $table->integer('contas_flk')->index('fk_contas_has_usuarios_contas_idx');
            $table->integer('usuarios_flk')->index('fk_contas_has_usuarios_usuarios1_idx');

            $table->primary(['contas_flk', 'usuarios_flk']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('contas_usuarios');
    }
}
