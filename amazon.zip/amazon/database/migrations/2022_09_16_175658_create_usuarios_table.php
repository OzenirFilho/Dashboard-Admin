<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsuariosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('usuarios', function (Blueprint $table) {
            $table->integer('id', true);
            $table->string('login', 100);
            $table->string('password', 150)->nullable();
            $table->string('email', 150)->nullable();
            $table->string('funcao_id', 100)->nullable();
            $table->string('master', 100)->nullable();
            $table->boolean('gerente');
            $table->boolean('colaborador');
            $table->boolean('admin');
            $table->string('permissoes', 500)->nullable();
            $table->string('comunicador_interno', 5);
            $table->string('avatar', 10000);

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('usuarios');
    }
}
