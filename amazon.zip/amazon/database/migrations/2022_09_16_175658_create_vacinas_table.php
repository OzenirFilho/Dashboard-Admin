<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVacinasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('vacinas', function (Blueprint $table) {
            $table->integer('id', true);
            $table->string('Nome', 100)->nullable();
            $table->string('Funcao', 80)->nullable();
            $table->string('Idade', 50)->nullable();
            $table->string('HepB1°', 50)->nullable();
            $table->string('HepB2°', 50)->nullable();
            $table->string('HepB3°', 50)->nullable();
            $table->string('Covid1°', 50)->nullable();
            $table->string('Covid2°', 50)->nullable();
            $table->string('Covid3°', 50)->nullable();
            $table->string('Covid4°', 50)->nullable();
            $table->string('DuplaTetanica1°', 50)->nullable();
            $table->string('DuplaTetanica2°', 50)->nullable();
            $table->string('DuplaTetanica3°', 50)->nullable();
            $table->string('Dt_Reforco', 50)->nullable();
            $table->string('FebreAmarela', 50)->nullable();
            $table->string('Fb_Reforco', 50)->nullable();
            $table->string('AntiHbsAnterior', 50)->nullable();
            $table->string('AntiHbsAtual', 50)->nullable();
            $table->string('GripeInfluenza', 300)->nullable();
            $table->string('PeriodicoAnterior', 50)->nullable();
            $table->string('PeriodicoAtual', 50)->nullable();
            $table->string('Ativo', 45)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('vacinas');
    }
}
